# Økt 10 - Oppsummering og veien videre (30. okt 2026)

Share-and-tell: del det du har laget og faktisk bruker, vi kårer champions og roller, og blir enige om veien videre. Ingen tvang - deling oppmuntres, ikke karaktersettes.

## Forarbeid (sendes fredag 23. okt, under 10 min)

- **Les:** utkast til handlingsplan og rollekart (fra uke 9).
- **Ta med:** har du noe å vise (1-2 min, ekte oppgave, før/etter)? ellers: den ene tingen du vil ta i bruk fremover, + svar på hvilken rolle du vil ha i REQs AI-arbeid.

## Oppsummering

*(kommer etter økten - kjør `/plugin update` for siste versjon)*
