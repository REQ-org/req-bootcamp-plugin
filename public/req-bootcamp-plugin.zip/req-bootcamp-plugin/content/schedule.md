# REQ AI Bootcamp - timeplan

Ni økter à ~60 minutter. Økt 1–2 var tirsdager kl. 08:30; fra økt 3 (4. september 2026) er serien fredager kl. 08:30. Økta 11. september ble utsatt en uke, så økt 4 og resten ligger én fredag senere - kurset avsluttes fortsatt 23. oktober 2026. Oppstart 18. august 2026 i Sommerrogata 17, Oslo (hybrid på Teams; første økt fysisk).

| # | Dato (08:30) | Tema |
|---|---|---|
| 01 | 18. aug 2026 | Fundament + plugin - intro, landskap/terminologi, modellvalg, tokens/latens |
| 02 | 25. aug 2026 | Skills - ekte skills i praksis, og bygg din egen |
| 03 | 4. sep 2026 | Projects, dokumenter og offentlige data - vedvarende kontekst, Word/PPT/Excel, SSB, Brreg, Kartverket og Oslo Planinnsyn |
| 04 | 18. sep 2026 | Arbeidsøkt - du bygger din egen ting; to innsendte caser løses i plenum (flyttet fra 11. sep) |
| 05 | 25. sep 2026 | Skriving og REQ-malen - utkast, omskriving, tone, korrektur, NO-EN og en gjenbrukbar mal-instruksjon |
| 06 | 2. okt 2026 | Analyse - repeterbare analyser (Claude Code / API-skript), JSON/Excel, widgets, verifikasjon av kilder |
| 07 | 9. okt 2026 | Bygge en MCP - hvordan en server bygges, enkel intern MCP-kobling, ukas agent |
| 08 | 16. okt 2026 | Trygg bruk - egenbygde MCP-er/skills, datatilgang, agentgrenser |
| 09 | 23. okt 2026 | Oppsummering og veien videre - del det du har laget, champions og roller |
